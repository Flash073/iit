print(" B-16 Spandan Gawade")

Basic_pay=float(input("Basic Salary Is :"))
hra=.1*Basic_pay
ta=.05*Basic_pay
Gross_salary=Basic_pay+hra+ta
tax=.02*Gross_salary
Total_salary=Gross_salary-tax


print("basic Pay is :", Basic_pay)
print("hra is :" , hra)
print("ta is : " , ta)
print("Gross salary is : " , Gross_salary)
print("tax is : " , tax)
print("Total salary is :" , Total_salary)
