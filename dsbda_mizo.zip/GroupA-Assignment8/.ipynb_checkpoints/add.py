a=6
b=7
print( "Addition is " , a + b)
print("Substraction  is " , a - b)
print("Multiplication is " , a * b)
print("Divison is " , a / b)
print("Modulus is " , a % b)

