import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score,confusion_matrix,classification_report

df=pd.read_csv("diabetes.csv")

df.head()

df.info()

df.describe()

df.isnull().sum()

df.isna().sum()

df.shape

plt.figure(figsize=(8,6))
sns.heatmap(df.corr(),annot=True,cmap='BuGn')
plt.show()

df.hist(figsize=(20,16))

x=df.iloc[:,:df.shape[1]-1]
y=df.iloc[:,-1]
print(x.shape,y.shape)

x_train,x_test,y_train,y_test=train_test_split(x,y,random_state=8,test_size=0.2)

x_train=StandardScaler().fit_transform(x_train)
x_test=StandardScaler().fit_transform(x_test)

def knn(x_train,x_test,y_train,y_test,neighbors,power):
    model=KNeighborsClassifier(n_neighbors=neighbors,p=power)
    y_pred=model.fit(x_train,y_train).predict(x_test)
    print(f"Accuracy for KNN: \t{accuracy_score(y_test,y_pred)}")
    cm = confusion_matrix(y_test, y_pred)
    print(f'''Confusion matrix :\n
    | Positive Prediction\t| Negative Prediction
    ---------------+------------------------+----------------------
    Positive Class | True Positive (TP) {cm[0, 0]}\t| False Negative (FN) {cm[0, 1]}
    ---------------+------------------------+----------------------
    Negative Class | False Positive (FP) {cm[1, 0]}\t| True Negative (TN) {cm[1, 1]}\n''')
    cr=classification_report(y_test,y_pred)
    print("Classification report: \n",cr)

param_grid = {'n_neighbors': range(1, 51),'p': range(1, 4)}
grid = GridSearchCV(estimator=KNeighborsClassifier(), param_grid=param_grid, cv=5)
print(grid.fit(x_train, y_train))
print(grid.best_estimator_, grid.best_params_, grid.best_score_)

print(knn(x_train, x_test, y_train, y_test, grid.best_params_['n_neighbors'], grid.best_params_['p']))
