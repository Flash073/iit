import pandas as pd 
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.ensemble import RandomForestRegressor

df=pd.read_csv('uber.csv')
df.head()

df.info()

print(df['pickup_datetime'].dtype)

df['pickup_datetime']=pd.to_datetime(df['pickup_datetime'])

print(df['pickup_datetime'].dtype)

df.describe()

df.isnull().sum()

df.dropna(inplace=True)

df.isnull().sum()

q_low = df["fare_amount"].quantile(0.01)
q_hi  = df["fare_amount"].quantile(0.99)

print(q_low,q_hi)

df

plt.boxplot(df['fare_amount'])
plt.show()

df=df[(df["fare_amount"] < q_hi) & (df["fare_amount"] > q_low)]

df.isnull().sum()

plt.boxplot(df['fare_amount'])
plt.show()

df.shape

#Take x as predictor variable
x = df.drop("fare_amount", axis = 1)
#And y as target variable
y = df['fare_amount']

print(x.shape)
print(y.shape)

print(df['pickup_datetime'].dtype)

x['pickup_datetime'] = pd.to_numeric(pd.to_datetime(x['pickup_datetime']))

x.head()

print(x['pickup_datetime'].dtype)

x = x.loc[:, x.columns.str.contains('^Unnamed')]

x.shape

x.head()

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2, random_state = 1)

lrmodel = LinearRegression()
lrmodel.fit(x_train, y_train)

#Prediction
predict = lrmodel.predict(x_test)

#Check Error
lrmodelrmse = np.sqrt(mean_squared_error(predict, y_test))
print("RMSE error for the model is ", lrmodelrmse)

rfrmodel = RandomForestRegressor(n_estimators = 100, random_state = 101)

#Fit the Forest
rfrmodel.fit(x_train, y_train)
rfrmodel_pred = rfrmodel.predict(x_test)

#Errors for the forest
rfrmodel_rmse = np.sqrt(mean_squared_error(rfrmodel_pred, y_test))
print("RMSE value for Random Forest is:",rfrmodel_rmse)
