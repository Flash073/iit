import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import LinearSVC, SVC
from sklearn import metrics

df=pd.read_csv("emails.csv")

df.head()

df.drop(columns=['Email No.'], inplace=True)

df.info()

df.describe()

df.isnull().sum()

df.isnull().sum()

X=df.iloc[:, :df.shape[1]-1]
print(X.shape)
y=df.iloc[:, -1]
print(y.shape)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.15, random_state=8)

models={
    "K-Nearest Neighbour: ":KNeighborsClassifier(n_neighbors=2),
    "Linear SVM: ":LinearSVC(random_state=8,max_iter=900000),
    "Polynomical SVM: ":SVC(kernel="poly",degree=2,random_state=8)
}

for model_name, model in models.items():
    y_pred=model.fit(X_train,y_train).predict(X_test)
    print(f"Accuracy for {model_name} model \t:{metrics.accuracy_score(y_test,y_pred)}")
